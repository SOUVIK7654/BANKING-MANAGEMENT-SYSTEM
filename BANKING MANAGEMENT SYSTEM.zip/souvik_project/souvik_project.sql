-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2023 at 05:23 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `souvik_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `aadhaar_no` text NOT NULL,
  `ac_no` text NOT NULL,
  `password` text NOT NULL,
  `ifsc_code` text NOT NULL,
  `address` text NOT NULL,
  `email` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `name`, `mobile`, `aadhaar_no`, `ac_no`, `password`, `ifsc_code`, `address`, `email`) VALUES
(1, 'debasish das', '6296062362', '863950328913', '035701100342', '11111111', 'UCBA00003', 'Kirnahar,731302', 'ddas1112000@gmail.com'),
(2, 'asim ', '9932848748', '123456789123', '123456789123', '123456', 'ucba12345', 'kirnahar', 'ddas1112000@gmail.com'),
(3, 'itu', '8158878264', '987654321123', '987654321123', '11111111', '147025836', 'Kirnahar,731302', 'itu@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `small_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `small_name`) VALUES
(1, 'ddas1112000@gmail.com', '111', 'D.Das');

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

CREATE TABLE `deposit` (
  `id` int(11) NOT NULL,
  `parent_id` text NOT NULL,
  `amount` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `name` text NOT NULL,
  `mobile` text NOT NULL,
  `giver_id` tinyint(4) DEFAULT NULL,
  `giver_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deposit`
--

INSERT INTO `deposit` (`id`, `parent_id`, `amount`, `date`, `name`, `mobile`, `giver_id`, `giver_name`) VALUES
(1, '1', '500', '2023-05-01 08:15:51', 'debasish das', '6296062362', NULL, ''),
(2, '1', '500', '2023-05-01 08:18:13', 'debasish das', '6296062362', NULL, ''),
(3, '1', '500', '2023-05-01 08:20:56', 'debasish das', '6296062362', NULL, ''),
(4, '2', '500', '2023-05-01 08:23:58', 'debasish das', '6296062362', 1, 'debasish das'),
(5, '3', '2000', '2023-05-01 14:55:39', 'itu', '8158878264', NULL, ''),
(6, '1', '1200', '2023-05-01 14:56:53', 'itu', '8158878264', 3, 'itu');

-- --------------------------------------------------------

--
-- Table structure for table `money_transfer`
--

CREATE TABLE `money_transfer` (
  `id` int(11) NOT NULL,
  `parent_id` text NOT NULL,
  `amount` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `receiver_id` tinyint(4) DEFAULT NULL,
  `receiver_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `money_transfer`
--

INSERT INTO `money_transfer` (`id`, `parent_id`, `amount`, `date`, `receiver_id`, `receiver_name`) VALUES
(1, '1', '500', '2023-05-01 08:23:58', 2, 'asim '),
(2, '3', '1200', '2023-05-01 14:56:53', 1, 'debasish das');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `money_transfer`
--
ALTER TABLE `money_transfer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `deposit`
--
ALTER TABLE `deposit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `money_transfer`
--
ALTER TABLE `money_transfer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
