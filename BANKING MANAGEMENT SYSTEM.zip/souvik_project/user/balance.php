<?php

include 'sessioncheck.php';
include '../constant.php';

$status = "";
$msg = "";

if (isset($_REQUEST['aadhaarno'])) 
{
    $aadhaarno = $_REQUEST['aadhaarno'];
    $password = $_REQUEST['password'];

    $sql = "SELECT * FROM account where aadhaar_no='$aadhaarno' and password='$password'";
    $result = $con->query($sql);
    if ($result->num_rows > 0) 
    {
        $result = $result->fetch_assoc();
        $account_id = $result['id'];

        $selectDeposit = $con->query("SELECT SUM(amount) AS total FROM deposit where parent_id='$account_id'")->fetch_assoc();
        $total_deposit = $selectDeposit['total'];

        $selectWithdraw = $con->query("SELECT SUM(amount) AS total FROM money_transfer where parent_id='$account_id'")->fetch_assoc();
        $total_withdraw = $selectWithdraw['total'];

        $status = 1;
        $balance = $total_deposit - $total_withdraw;
        $msg = "Your Balance is <b>".$balance."</b>";
        
    }
    else
    {
             $status = 0;
             $msg = "This Aadhaar or Password is not exists";
    }
}



?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include "layout/header.php";
        ?>
    </head>
    <body class="sb-nav-fixed" style="background-color: paleturquoise;">
        <?php
        include 'layout/topnavbar.php'; 
        ?>
        <div id="layoutSidenav">

            <?php
            include 'layout/sidenavbar.php';
            ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4 m-3">
                        <div class="contain">
                        <div class="header h3 my-4">Balance Enquery</div>
                          <form method="POST" action="" class="deposit_form" novalidate>
                              <div class="mb-3">
                                <label for="aadhaarno" class="form-label">Aadhaar Number</label>
                                <input type="number" class="form-control" maxlength="12" minlength="12" name="aadhaarno" required>
                                <div class="invalid-feedback">
                                    Please enter your Aadhaar Number
                                </div>
                              </div>

                              <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" maxlength="8" minlength="8" name="password" required>
                                <div class="invalid-feedback">
                                    Please enter your Password
                                </div>
                              </div>


                              <button type="submit" class="btn btn-primary" name="submitBtn">Submit</button>

                                <?php
                                if ($status == 1) 
                                {?>
                                    <div class="alert alert-warning my-2"><?=$msg?></div>
                                <?php
                                }
                                else if($status == 0)
                                {?>
                                    <div class="alert alert-danger my-2"><?=$msg?></div>
                                <?php
                                }
                                else
                                {}
                                ?>

                        </form>
                    </div>
                    </div>
                </main>
            <?php
            include 'layout/footer.php';
            ?>
            <script type="text/javascript">
                $("#balance").addClass("active");
            </script>
        </div>
    </div>

    <script type="text/javascript">

    </script>

    </body>
</html>
