<?php

include 'sessioncheck.php';
include '../constant.php';

if (isset($_SESSION['id'])) {
    $id = $_SESSION['id'];
    $sql = "SELECT * FROM account where id ='$id'";
    $row_array = $con->query($sql)->fetch_assoc();

    $name = $row_array['name'];
    $email = $row_array['email'];
    $address = $row_array['address'];
    $aadhaarno = $row_array['aadhaar_no'];
    $ac_no = $row_array['ac_no'];
    $ifsc = $row_array['ifsc_code'];
    $password = $row_array['password'];
    $mobile = $row_array['mobile'];

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include "layout/header.php";
        ?>
    </head>
    <body class="sb-nav-fixed" style="background-color: paleturquoise;">
<?php
include 'layout/topnavbar.php'; 
?>
<div id="layoutSidenav">

    <?php
    include 'layout/sidenavbar.php';
    ?>

    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
               <h3 class="mt-3">Your Profile</h3>
                  <form class="row g-3 my-3" method="POST" action="">
                      <div class="col-md-6">
                        <label for="inputEmail4" class="form-label">Name</label>
                        <input type="text" class="form-control-plaintext" value="<?=$name ; ?>" name="name" required>
                      </div>
                      <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Email</label>
                        <input type="email" class="form-control" value="<?=$email ; ?>" name="email" required>
                      </div>
                      <div class="col-12">
                        <label for="inputAddress" class="form-label">Address</label>
                        <input type="text" class="form-control" value="<?=$address ; ?>" name="address" required>
                      </div>

                       <div class="col-md-6">
                        <label for="inputEmail4" class="form-label">Mobile Number</label>
                        <input type="number" class="form-control" value="<?=$mobile ; ?>" name="mobile" required>
                      </div>

                      <div class="col-md-6">
                        <label for="inputEmail4" class="form-label">Aadhaar Number</label>
                        <input type="number" class="form-control" value="<?=$aadhaarno ; ?>" name="aadhaar_no" required>
                      </div>
                      <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Account Number</label>
                        <input type="number" name="ac_no" value="<?=$ac_no ; ?>" class="form-control" required>
                      </div>

                      <div class="col-md-6">
                        <label for="inputEmail4" class="form-label">IFSC code</label>
                        <input type="text" class="form-control" value="<?=$ifsc ; ?>" name="ifsc_code" required>
                      </div>
                      <div class="col-md-6">
                        <label for="inputPassword4" class="form-label">Password</label>
                        <input type="number" name="password" value="<?=$password ; ?>" class="form-control" required>
                      </div>
                    </form>
            </div>
        </main>
    <?php
    include 'layout/footer.php';
    ?>
   
</div>
</div>
    <script type="text/javascript">
        $("#profile").addClass("active");
        // $("#create_ac").addClass("active");
        // $(".account_child").addClass("show");
        // $("#create_ac").parent().parent().siblings(".account_parent").removeClass("collapsed");
    </script>

    </body>
</html>

