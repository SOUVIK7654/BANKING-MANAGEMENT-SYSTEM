<?php

include 'sessioncheck.php';
include '../constant.php';

$status = "";
$msg = "";

if (isset($_REQUEST['aadhaarno'])) 
{
    $name = $_REQUEST['name'];
    $aadhaarno = $_REQUEST['aadhaarno'];
    $mobile = $_REQUEST['mobile'];
    $amount = $_REQUEST['amount'];

    $sql = "SELECT * FROM account where aadhaar_no='$aadhaarno' LIMIT 1;";
    $result = $con->query($sql);
    if ($result->num_rows > 0) 
    {
        $result = $result->fetch_assoc();
        $account_id = $result['id'];
        $sql = "INSERT INTO `deposit`(`parent_id`, `amount`, `name`, `mobile`) VALUES ('$account_id','$amount','$name','$mobile')";
        if ($con->query($sql) == TRUE) 
        {
             $status = 1;
             $msg = "Deposit Successfully";
        }
        else
        {
             $status = 0;
             $msg = $con->error;
        }
    }
    else
    {
             $status = 0;
             $msg = "This aadhaar is not registered";
    }
}


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include "layout/header.php";
        ?>
    </head>
    <body class="sb-nav-fixed">
        <?php
        include 'layout/topnavbar.php'; 
        ?>
        <div id="layoutSidenav">

            <?php
            include 'layout/sidenavbar.php';
            ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4 m-3">
                        <div class="contain">
                        <div class="header h3 my-4">Deposit Cash</div>
                          <form method="POST" action="" class="deposit_form" novalidate>
                              <div class="mb-3">
                                <label for="aadhaarno" class="form-label">Aadhaar Number</label>
                                <input type="number" class="form-control" maxlength="12" minlength="12" name="aadhaarno" required>
                                <div class="invalid-feedback">
                                    Please enter your Aadhaar Number
                                </div>
                              </div>
                              <div class="mb-3">
                                <label for="aadhaarno" class="form-label">Name</label>
                                <input type="text" class="form-control" name="name" required>
                                <div class="invalid-feedback">
                                    Please enter your Name
                                </div>
                              </div>
                              <div class="mb-3">
                                <label for="mobile" class="form-label">Mobile Number</label>
                                <input type="number" class="form-control" maxlength="10" minlength="10"   name="mobile" required>
                                <div class="invalid-feedback">
                                    Please enter your Mobile Number
                                </div>
                              </div>
                              <div class="mb-3">
                                <label for="amount" class="form-label">Deposit Amount</label>
                                <input type="number" class="form-control" name="amount" required>
                                <div class="invalid-feedback">
                                    Please enter your Deposit Amount
                                </div>
                              </div>


                              <button type="submit" class="btn btn-primary" name="submitBtn">Submit</button>

                                <?php
                                if ($status == 1) 
                                {?>
                                    <div class="alert alert-success my-2"><?=$msg?></div>
                                <?php
                                }
                                else if($status == 0)
                                {?>
                                    <div class="alert alert-danger my-2"><?=$msg?></div>
                                <?php
                                }
                                else
                                {}
                                ?>

                        </form>
                    </div>
                    <div class="h3 my-3">Deposit Details</div>
                        <table class="table table-striped mt-2 deposit_table">
                            <thead>
                                <tr>
                                  <th scope="col">Deposit By</th>
                                  <th scope="col">Amount</th>
                                  <th scope="col">Date</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php
                                $id = $_SESSION['id'];
                                $selectquery=mysqli_query($con,"SELECT * FROM `deposit` where `parent_id`='$id'  ORDER BY id DESC;");
                                while ($row=mysqli_fetch_assoc($selectquery)) {
                                    $date = explode(" ", $row['date'])[0];
                                    $newDate = date("d M Y", strtotime($date));
                                    if(is_null($row['giver_id'])) {
                                      $deposit_by = "You";
                                    } else {
                                      $deposit_by = $row['giver_name'];
                                    }
                                ?>

                                <tr class="">
                                  <td><?=$deposit_by;?></td>
                                  <td><?=$row['amount'];?></td>
                                  <td><?=$newDate;?></td>
                                  
                                </tr>

                                <?php
                                }?>
                            </tbody>
                        </table>
                    </div>
                </main>
            <?php
            include 'layout/footer.php';
            ?>
            
        </div>
    </div>
<script type="text/javascript">
    $("#deposit").addClass("active");
</script>
<script type="text/javascript">
    $(".deposit_table").DataTable();
</script>
<script type="text/javascript">
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.deposit_form')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()

</script>
    </body>
</html>
