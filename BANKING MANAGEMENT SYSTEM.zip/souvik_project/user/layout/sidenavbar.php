         <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <!-- <div class="sb-sidenav-menu-heading">Core</div> -->
                            <a class="nav-link" href="profile.php" id="profile">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Profile
                            </a>
                            <a class="nav-link" href="money_transfer.php" id="withdraw">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Money Transfer
                            </a>
                            <!-- <a class="nav-link" href="deposit.php" id="deposit">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Diposit
                            </a> -->
                            <a class="nav-link" href="balance.php" id="balance">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Check Balance
                            </a>
                            <!-- <a class="nav-link collapsed account_parent" href="#" data-bs-toggle="collapse" data-bs-target="#account" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Account
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse account_child" id="account" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" id="create_ac" href="create_ac.php">Create A/c</a>
                                </nav>
                            </div>
                            <div class="collapse account_child" id="account" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" id="manage_ac" href="manage_ac.php">Manage A/c</a>
                                </nav>
                            </div> -->

                        </div>
                    </div>
                    
                </nav>
            </div>