<?php
session_start();
include 'sessioncheck.php';
include '../constant.php';

$status = "";
$msg = "";

if (isset($_REQUEST['ac_no'])) {
  $ac_no = $_REQUEST['ac_no'];
  $ifsc_code = $_REQUEST['ifsc_code'];
  $password = $_REQUEST['password'];
  $amount = $_REQUEST['amount'];
  $sql = "SELECT * FROM account where ac_no='$ac_no' and ifsc_code='$ifsc_code'  LIMIT 1";
  $result = $con->query($sql);
  if ($password == $_SESSION['password']) {
    if ($result->num_rows > 0) {
      $result = $result->fetch_assoc();
      $receiver_id = $result['id'];
      $receiver_name = $result['name'];
      $self_id = $_SESSION['id'];
      $self_name = $_SESSION['name'];
      $self_mobile = $_SESSION['mobile'];

      $selectDeposit = $con->query("SELECT SUM(amount) AS total FROM deposit where parent_id='$self_id'")->fetch_assoc();
      $total_deposit = $selectDeposit['total'];

      $selectWithdraw = $con->query("SELECT SUM(amount) AS total FROM money_transfer where parent_id='$self_id'")->fetch_assoc();
      $total_withdraw = $selectWithdraw['total'];
      $balance = $total_deposit - $total_withdraw;

      if ($balance) {
        $sql = "INSERT INTO `money_transfer`(`receiver_name`, `receiver_id`,`parent_id`, `amount`) VALUES ('$receiver_name', '$receiver_id', '$self_id', '$amount')";
        $transfer_insert = $con->query($sql);

        $sql = "INSERT INTO `deposit`(`giver_name`, `giver_id`, `parent_id`, `amount`, `name`, `mobile`) VALUES ('$self_name', '$self_id', '$receiver_id','$amount','$self_name','$self_mobile')";
        $deposit_insert = $con->query($sql);

        if ($transfer_insert && $deposit_insert) {
          $status = 1;
          $balance += -$amount;
          $msg = "Money Transfer Successfully <br> Your Balance is <b>Rs " . $balance;
        } else {
          $status = 0;
          $msg = $con->error;
        }
      } else {
        $status = 0;
        $msg = "You do not have sufficient amount to Withdraw";
      }
    } else {
      $status = 0;
      $msg = "This Account Number or IFSC Code is not exists / match";
    }
  } else {
    $status = 0;
    $msg = "This Password is not exists / match";
  }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php
  include "layout/header.php";
  ?>
</head>

<body class="sb-nav-fixed" style="background-color: paleturquoise;">
  <?php
  include 'layout/topnavbar.php';
  ?>
  <div id="layoutSidenav">

    <?php
    include 'layout/sidenavbar.php';
    ?>

    <div id="layoutSidenav_content">
      <main>
        <div class="container-fluid px-4 m-3">
          <div class="contain">
            <div class="header h3 my-4">Money Transfer</div>
            <form method="POST" action="" class="withdraw_form" novalidate>
              <div class="row mb-3">
                <div class="col-md-6">
                  <label for="aadhaarno" class="form-label">Account Number</label>
                  <input type="text" class="form-control" name="ac_no" minlength="12" maxlength="12" required>
                  <div class="invalid-feedback">
                    Please enter your Account Number
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="mb-3">
                    <label for="aadhaarno" class="form-label">IFSC Code</label>
                    <input type="text" class="form-control" name="ifsc_code" required>
                    <div class="invalid-feedback">
                      Please enter your IFSC Code
                    </div>
                  </div>
                </div>
              </div>

              <div class="row mb-3">
                <div class="col-md-6">
                  <div class="mb-3">
                    <label for="password" class="form-label">Amount</label>
                    <input type="number" class="form-control" name="amount" required>
                    <div class="invalid-feedback">
                      Please enter your Amount
                    </div>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" required>
                    <div class="invalid-feedback">
                      Please enter your Password
                    </div>
                  </div>
                </div>
              </div>

              <input type="submit" class="btn btn-primary" value="Submit">

              <?php
              if ($status == 1) { ?>
                <div class="alert alert-success my-2"><?= $msg ?></div>
              <?php
              } else if ($status == 0) { ?>
                <div class="alert alert-danger my-2"><?= $msg ?></div>
              <?php
              } else {
              }
              ?>

            </form>
          </div>
          <div class="h3 my-3">Transation Details</div>
          <table class="table table-striped mt-2 withdraw_table">
            <thead>
              <tr>
                <th scope="col">Send To</th>
                <th scope="col">Amount</th>
                <th scope="col">Date</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $id = $_SESSION['id'];
              $selectquery = mysqli_query($con, "SELECT * FROM `money_transfer` where `parent_id`='$id'  ORDER BY id DESC;");
              while ($row = mysqli_fetch_assoc($selectquery)) {
                $date = explode(" ", $row['date'])[0];
                $newDate = date("d M Y", strtotime($date));
              ?>

                <tr class="">
                  <td><?= $row['receiver_name']; ?></td>
                  <td><?= $row['amount']; ?></td>
                  <td><?= $newDate; ?></td>

                </tr>

              <?php
              } ?>
            </tbody>
          </table>
        </div>
      </main>


      <?php
      include 'layout/footer.php';
      ?>
    </div>
  </div>

  <script type="text/javascript">
    $("#withdraw").addClass("active");
  </script>
  <script type="text/javascript">
    $(".withdraw_table").DataTable();
  </script>

  <script type="text/javascript">
    (function() {
      'use strict'

      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      var forms = document.querySelectorAll('.withdraw_form')

      // Loop over them and prevent submission
      Array.prototype.slice.call(forms)
        .forEach(function(form) {
          form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
            }

            form.classList.add('was-validated')
          }, false)
        })
    })()
  </script>

</body>

</html>