<?php

include 'constant.php';
$status = "";
$msg = "";

if (isset($_REQUEST['aadhaarno'])) 
{
	$aadhaarno = $_REQUEST['aadhaarno'];
	$password = $_REQUEST['password'];
	$amount = $_REQUEST['amount'];

	$sql = "SELECT * FROM account where aadhaar_no='$aadhaarno' and password='$password'";
	$result = $con->query($sql);
	if ($result->num_rows > 0) 
	{
		$result = $result->fetch_assoc();
		$account_id = $result['id'];

		$selectDeposit = $con->query("SELECT SUM(amount) AS total FROM deposit where parent_id='$account_id'")->fetch_assoc();
		$total_deposit = $selectDeposit['total'];

		$selectWithdraw = $con->query("SELECT SUM(amount) AS total FROM withdraw where parent_id='$account_id'")->fetch_assoc();
		$total_withdraw = $selectWithdraw['total'];
		$balance = $total_deposit - $total_withdraw;

			if ($balance) 
			{
					$sql = "INSERT INTO `withdraw`(`parent_id`, `amount`) VALUES ('$account_id', '$amount')";
					if ($con->query($sql) == TRUE) 
					{
						 $status = 1;
						 $balance += -$amount;
						 $msg = "Withdraw Successfully <br>
						 					Your Balance is <b>Rs ".$balance;
					}
					else
					{
						 $status = 0;
						 $msg = $con->error;
					}
			}
			else
			{
				$status = 0;
				$msg = "You do not have sufficient amount to Withdraw";
			}
	}
	else
	{
			 $status = 0;
			 $msg = "This Aadhaar or Password is not exists";
	}
}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Withdraw Cash</title>
	<link rel="stylesheet" type="text/css" href="file/bootstrap.css">
</head>
<body style="height: 100vh;">
	
	<?php
	include 'navContent.php';
	?>

	<div class="container mt-5 col-6">
		<div class="contain">
			<div class="header h3 my-4">Withdraw Cash</div>
			  <form method="POST" action="" class="withdraw_form" novalidate>
				  <div class="mb-3">
				    <label for="aadhaarno" class="form-label">Aadhaar Number</label>
				    <input type="number" class="form-control" name="aadhaarno" required>
				    <div class="invalid-feedback">
				    	Please enter your Aadhaar Number
				    </div>
				  </div>

				  <div class="mb-3">
				    <label for="password" class="form-label">Withdraw Amount</label>
				    <input type="number" class="form-control" name="amount" required>
				    <div class="invalid-feedback">
				    	Please enter your Amount
				    </div>
				  </div>

				  <div class="mb-3">
				    <label for="password" class="form-label">Password</label>
				    <input type="password" class="form-control" name="password" required>
				    <div class="invalid-feedback">
				    	Please enter your Password
				    </div>
				  </div>

				  <div class="mb-3 divsmg" style="display: none;">
				    <div class="alert alert-success sussessmsg"></div>
				    <div class="alert alert-danger errormsg"></div>
				  </div>

				  <input type="submit" class="btn btn-primary" value="Submit">

				  <?php
			  	if ($status == 1) 
			  	{?>
			  		<div class="alert alert-success my-2"><?=$msg?></div>
			  	<?php
			  	}
			  	else if($status == 0)
			  	{?>
			  		<div class="alert alert-danger my-2"><?=$msg?></div>
			  	<?php
			  	}
			  	else
			  	{}
			  	?>
			</form>
		</div>
	</div>
<script type="text/javascript" src="file/bootstrap.bundle.js"></script>
<!-- <script type="text/javascript" src="file/bootstrap.esm.js"></script> -->
<script type="text/javascript" src="file/bootstrap.js"></script>
<script type="text/javascript" src="file/jquery-3.6.1.min.js"></script>

<script type="text/javascript">
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.withdraw_form')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()

	$(".nav-link").removeClass("active");
	$("#withdrawlink").addClass("active");
</script>
</body>
</html>