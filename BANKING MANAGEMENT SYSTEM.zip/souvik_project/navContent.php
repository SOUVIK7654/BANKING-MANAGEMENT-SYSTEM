<nav class="navbar navbar-expand-lg navbar-light bg-light px-3">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="#"><b>BITM Banking System</b></a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarNav">
	      <ul class="navbar-nav">
	        <!-- <li class="nav-item">
	          <a class="nav-link active" id="withdrawlink" href="withdraw.php">Withdraw Cash</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" id="depositlink" href="deposit.php">Deposit Cash</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" id="balance_check" href="balance_check.php">Balance Check</a>
	        </li> -->

	        <li class="nav-item float-right">
	          <a class="btn btn-primary" id="balance_check" href="user/">User login</a>
	        </li>
	        <div>
	        	 <li class="nav-item float-right" style="padding: 1px;">
	          <a class="btn btn-primary" id="balance_check" href="admin/">Admin login</a>
	        </li>

	        </div>

	      </ul>
	    </div>
	  </div>
	</nav>