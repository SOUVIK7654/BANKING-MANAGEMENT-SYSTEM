<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>BITM project</title>
	<link rel="stylesheet" type="text/css" href="file/bootstrap.css">
	<style>
		body{
			background-color: blue;
		}
	</style>
</head>
<body>
	
	<?php
	include 'navContent.php';
	?>

	<div class="container my-5">
		<h2 class="mx-3" style="color:white;">Welcome to BITM Banking System</h2>
	</div>

<script type="text/javascript" src="file/bootstrap.bundle.js"></script>
<script type="text/javascript" src="file/bootstrap.esm.js"></script>
<script type="text/javascript" src="file/bootstrap.js"></script>
</body>
</html>