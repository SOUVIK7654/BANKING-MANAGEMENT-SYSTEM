<?php

include 'sessioncheck.php';
include '../constant.php';

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include "layout/header.php";
        ?>
    </head>
    <body class="sb-nav-fixed" style="background-color: pink;">
        <?php
        include 'layout/topnavbar.php'; 
        ?>
        <div id="layoutSidenav">

            <?php
            include 'layout/sidenavbar.php';
            ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4 m-3">
                        <h3>welcome to BITM Banking System</h3>

                    </div>
                </main>
            <?php
            include 'layout/footer.php';
            ?>
            <script type="text/javascript">
                $("#dashboard").addClass("active");
            </script>
        </div>
    </div>

    <script type="text/javascript">

    </script>

    </body>
</html>
