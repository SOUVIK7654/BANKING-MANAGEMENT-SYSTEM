
		<meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - BITM Project</title>
        <link href="css/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
        <script src="js/all.js" crossorigin="anonymous"></script>
        <style type="text/css">
        	.active{
        		color: white;
    			background-color: #5c5858;
        	}
        </style>


