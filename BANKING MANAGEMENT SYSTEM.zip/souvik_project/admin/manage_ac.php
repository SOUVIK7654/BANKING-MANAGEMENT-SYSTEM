<?php

include 'sessioncheck.php';
include '../constant.php';

if (isset($_REQUEST['dlt_id'])) {
    $dlt_id = $_REQUEST['dlt_id'];

    $sql = "DELETE FROM account WHERE id = '$dlt_id'";
    $runQuery = $con->query($sql);
    if ($runQuery) {
       $result = "Account has been deleted successfully.";
    }
    
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include "layout/header.php";
        ?>
    </head>
    <body class="sb-nav-fixed" style="background-color: yellowgreen;">
        <?php
        include 'layout/topnavbar.php'; 
        ?>
        <div id="layoutSidenav">

            <?php
            include 'layout/sidenavbar.php';
            ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                       <h3 class="mt-3">User Details</h3>
                       <?php
                       if (isset($result)) 
                       {
                           echo "<div class='alert alert-success my-3'>{$result}</div>";
                       }
                       ?>
                           <table class="table table-striped mt-2">
                                <thead>
                                    <tr>
                                      <th scope="col">User name</th>
                                      <th scope="col">Email</th>
                                      <th scope="col"></th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                    $selectquery=mysqli_query($con,"SELECT * FROM `account` ORDER BY id DESC;");
                                    while ($row=mysqli_fetch_assoc($selectquery)) {
                                    ?>

                                    <tr>
                                      <td><?=$row['name'];?></td>
                                      <td><?=$row['email'];?></td>
                                      <td>
                                          <a href="create_ac.php?id=<?=$row['id']?>" class="btn btn-primary btn-sm">View</a>
                                          <a href="withdraw.php?id=<?=$row['id']?>" class="btn btn-success btn-sm">Money Transfers</a>
                                          <a href="deposit.php?id=<?=$row['id']?>" class="btn btn-info btn-sm">View Deposit</a>
                                          <a href="manage_ac.php?dlt_id=<?=$row['id']?>" onclick="return confirm('Are you sure ?')" class="btn btn-danger btn-sm">Delete</a>
                                      </td>
                                    </tr>

                                    <?php
                                    }?>
                                </tbody>
                            </table>


                    </div>
                </main>
            <?php
            include 'layout/footer.php';
            ?>
           
        </div>
    </div>
    <script type="text/javascript">
        $("#manage_ac").addClass("active");
        $(".account_child").addClass("show");
        $("#manage_ac").parent().parent().siblings(".account_parent").removeClass("collapsed");
    </script>

    </body>
</html>

