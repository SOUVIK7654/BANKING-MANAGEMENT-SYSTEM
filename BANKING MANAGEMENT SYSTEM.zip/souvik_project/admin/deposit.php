<?php

include 'sessioncheck.php';
include '../constant.php';
$id = $_REQUEST['id'];
$selectquery=mysqli_query($con,"SELECT * FROM `deposit` WHERE `parent_id` = '$id' ORDER BY id DESC;");


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include "layout/header.php";
        ?>
        <style type="text/css">
            body{
                background-color: yellowgreen;
            }
        </style>
    </head>
    <body class="sb-nav-fixed" style="background-color: yellowgreen;">
        <?php
        include 'layout/topnavbar.php'; 
        ?>
        <div id="layoutSidenav">

            <?php
            include 'layout/sidenavbar.php';
            ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                       <h3 class="mt-3">Deposit Details</h3>
                       <?php
                       if (isset($result)) 
                       {
                           echo "<div class='alert alert-success my-3'>{$result}</div>";
                       }
                       ?>
                           <table class="table table-striped mt-2">
                                <thead>
                                    <tr>
                                      <th scope="col">Deposit By</th>
                                      <th scope="col">Date</th>
                                      <th scope="col">Amount</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                    while ($row=mysqli_fetch_assoc($selectquery)) {
                                        $date = date('d/m/Y', strtotime(explode(" ", $row['date'])[0]));
                                        $amout = $row['amount'];
                                        if(empty($row['giver_name'])) {
                                            $row['giver_name'] = "Self Deposit";
                                        }
                                    ?>

                                    <tr>
                                      <td><?=$row['giver_name'];?></td>
                                      <td><?=$date;?></td>
                                      <td><?=$amout;?></td>
                                    </tr>

                                    <?php
                                    }?>
                                </tbody>
                            </table>


                    </div>
                </main>
            <?php
            include 'layout/footer.php';
            ?>
           
        </div>
    </div>
    <script type="text/javascript">
        $("#manage_ac").addClass("active");
        $(".account_child").addClass("show");
        $("#manage_ac").parent().parent().siblings(".account_parent").removeClass("collapsed");
    </script>

    </body>
</html>

