<?php

include 'sessioncheck.php';
include '../constant.php';

$status = "";

$name = "";
$email = "";
$address = "";
$aadhaarno = "";
$ac_no = "";
$ifsc = "";
$password = "";
$mobile = "";
$error = array();

if (isset($_REQUEST['id'])) {
    $id = $_REQUEST['id'];
    $sql = "SELECT * FROM account where id ='$id'";
    $row_array = $con->query($sql)->fetch_assoc();

    $name = $row_array['name'];
    $email = $row_array['email'];
    $address = $row_array['address'];
    $aadhaarno = $row_array['aadhaar_no'];
    $ac_no = $row_array['ac_no'];
    $ifsc = $row_array['ifsc_code'];
    $password = $row_array['password'];
    $mobile = $row_array['mobile'];

}

if (isset($_REQUEST['btnSubmit'])) 
{
    $post = json_decode(json_encode($_POST));
    
    foreach ($post as $property => $value)  {
        if ($property == "aadhaar_no" or $property == "mobile" or $property == "ac_no") {
          if($property == "aadhaar_no") {
            $property = "Aadhaar Number";
          }

          if($property == "mobile") {
            $property = "Mobile Number";
          }

          if($property == "ac_no") {
            $property = "Account Number";
          }
          
            if(!is_numeric($value)){
                $error[] = "{$property} must be numeric";
            }
        }
    }

    if(count($error) == 0) {
        $sql = "INSERT INTO `account` SET `name`='$post->name', `aadhaar_no`='$post->aadhaar_no', `mobile`='$post->mobile',`ac_no`='$post->ac_no', `password`='$post->password', `ifsc_code`='$post->ifsc_code', `address`='$post->address', `email`='$post->email'";
        $insert = $con->query($sql);
        if ($insert) 
        {
            $status = "success";
            $msg = "Account has been created successfully";
        }
        else
        {
            $status = "error";
            $msg = "Something is error";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include "layout/header.php";
        ?>
    </head>
    <body class="sb-nav-fixed" style="background-color: yellowgreen;">
        <?php
        include 'layout/topnavbar.php'; 
        ?>
        <div id="layoutSidenav">

            <?php
            include 'layout/sidenavbar.php';
            ?>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                       <h3 class="mt-3">Dislpay Messages</h3>
                       <?php
                       if ($status == "success") {
                       ?>
                       <div class="alert alert-success my-3"><?= $msg ;?></div>
                       <?php
                        }else if($status == "error"){
                        ?>
                       <div class="alert alert-danger my-3"><?= $msg ;?></div>
                       <?php
                        }
                        if (count($error) > 0) {
                            foreach ($error as $key => $value) {
                        ?>
                        <div class="alert alert-danger my-3"><?= $value ;?></div>
                        <?php
                        }
                        }?>

                          <form class="row g-3 my-3" method="POST" action="">
                              <div class="col-md-6">
                                <label for="inputEmail4" class="form-label">Name</label>
                                <input type="text" class="form-control" value="<?=$name ; ?>" name="name" required>
                              </div>
                              <div class="col-md-6">
                                <label for="inputPassword4" class="form-label">Email</label>
                                <input type="email" class="form-control" value="<?=$email ; ?>" name="email" required>
                              </div>
                              <div class="col-12">
                                <label for="inputAddress" class="form-label">Address</label>
                                <input type="text" class="form-control" value="<?=$address ; ?>" name="address" required>
                              </div>

                               <div class="col-md-6">
                                <label for="inputEmail4" class="form-label">Mobile Number</label>
                                <input type="text" class="form-control" minlength="10" maxlength="10" value="<?=$mobile ; ?>" name="mobile" required>
                              </div>

                              <div class="col-md-6">
                                <label for="inputEmail4" class="form-label">Aadhaar Number</label>
                                <input type="text" class="form-control" minlength="12" maxlength="12" value="<?=$aadhaarno ; ?>" name="aadhaar_no" required>
                              </div>
                              <div class="col-md-6">
                                <label for="inputPassword4" class="form-label">Account Number</label>
                                <input type="text" name="ac_no" minlength="12" maxlength="12" value="<?=$ac_no ; ?>" class="form-control" required>
                              </div>

                              <div class="col-md-6">
                                <label for="inputEmail4" class="form-label">IFSC code</label>
                                <input type="text" class="form-control" minlength="9" maxlength="9"  value="<?=$ifsc ; ?>" name="ifsc_code" required>
                              </div>
                              <div class="col-md-6">
                                <label for="inputPassword4" class="form-label">Password</label>
                                <input type="password" name="password" minlength="6" maxlength="8"  value="<?=$password ; ?>" class="form-control" required>
                              </div>
                              <?php
                              if (!isset($id)) {
                              ?>
                              <div class="col-12">
                                <input type="submit" class="btn btn-primary" name="btnSubmit" value="Create A/c">
                              </div>
                              <?php
                                }
                                ?>
                            </form>
                    </div>
                </main>
            <?php
            include 'layout/footer.php';
            ?>
           
        </div>
    </div>
    <script type="text/javascript">
        $("#create_ac").addClass("active");
        $(".account_child").addClass("show");
        $("#create_ac").parent().parent().siblings(".account_parent").removeClass("collapsed");
    </script>

    </body>
</html>

